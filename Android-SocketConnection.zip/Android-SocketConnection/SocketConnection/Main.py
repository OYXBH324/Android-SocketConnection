import socket
import socketserver
from io import BytesIO

import cv2
import kociemba
from PIL import Image
import numpy as np

from CubeColorDetect import analyse

BUFSIZE = 1024

class myTCPhandler(socketserver.BaseRequestHandler):
    def handle(self):
        size = self.request.recv(10)
        size_str = str(size, encoding='utf-8')
        size_str = size_str.strip()
        file_size = int(size_str)
        print("数据长度:", size_str)
        now_size = 0
        res = []
        ok = False
        while True:
            if now_size == file_size :
                break
            data = self.request.recv(BUFSIZE)  # 4.接收数据
            #print(len(data))
            if not data:
                break

            if ok == True :
                res = res + data
            else:
                res = data
                ok = True
            now_size += len(data)
            #print("now_size:", now_size, " res size:", len(res), "res :", res)

        bytes_stream = BytesIO(res)
        capture_img = Image.open(bytes_stream)
        #capture_img.show()
        img = cv2.cvtColor(np.asarray(capture_img), cv2.COLOR_RGB2BGR)
        analyse(img)

        s = "hello"
        self.request.sendall(s.encode("utf-8"))  # 5.发送数据


hostip = '192.168.123.14'
port = 8000
print(kociemba.solve('UBRLUFFUBLRUFRLLLRDBDRFDBBUDDBUDDLRFBFLDLBFFRFLRUBRDUU'))
server = socketserver.ThreadingTCPServer((hostip, port), myTCPhandler)
server.serve_forever()
